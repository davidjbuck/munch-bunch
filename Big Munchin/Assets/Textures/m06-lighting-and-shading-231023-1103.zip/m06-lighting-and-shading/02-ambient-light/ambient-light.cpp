


#include <GLM/gtc/type_ptr.hpp>


#include <iostream>


#include <glad/gl.h>
#include <GLFW/glfw3.h>

#include "learnopengl/shader_4722.h"

#include "cs4722/artifact.h"
#include "cs4722/view.h"
#include "../callbacks.h"
#include "cs4722/light.h"
//#include "cs4722/utility.h"
#include "cs4722/window.h"
#include "cs4722/buffer_utilities.h"

static cs4722::view *the_view;
static Shader *shader;
static GLuint vao;

static std::vector<cs4722::artifact*> artifact_list;

/*
 * Declare a light object.
 * The default ambient color of a light object is Gray50.
 */
static cs4722::light a_light;

void init()
{

    a_light.ambient_light = cs4722::x11::white;
//    a_light.ambient_light = cs4722::x11::black;
//    a_light.ambient_light = cs4722::x11::gray50;
//    a_light.ambient_light = cs4722::x11::blue;
//    a_light.ambient_light = cs4722::color(64, 64, 255);




    the_view = new cs4722::view();

    shader = new Shader("vertex_shader02.glsl","fragment_shader02.glsl");
	shader->use();

    glEnable(GL_DEPTH_TEST);


	// create a list of shapes that will be shared by the objects we have

	const auto color_set = std::vector <cs4722::color>({
			cs4722::x11::white, cs4722::x11::grey50, cs4722::x11::grey75,
		});
	
	auto* shape_list = new std::vector<cs4722::shape*>();
	shape_list->push_back(new cs4722::sphere());
	shape_list->push_back(new cs4722::block());
	shape_list->push_back(new cs4722::torus());
	shape_list->push_back(new cs4722::cylinder());
	auto numshp = shape_list->size();



	auto number = 8;
	auto d = 100.0f / (2 * number + 1);
	auto radius = d / 4;
	auto base = -number * d / 2 + radius;

	for (auto x = 0; x < number; ++x)
	{
		for (auto y = 0; y < number; ++y)
		{
			for (auto z = 0; z < number; ++z)
			{
				auto* artf = new cs4722::artifact_rotating();
				artf->the_shape = (shape_list->at((x + y + z) % numshp));
				artf->world_transform.translate = (glm::vec3(base + x * d, base + y * d, base + z * d));
				artf->world_transform.scale = (glm::vec3(radius, radius, radius));
                artf->animation_transform.rotation_axis = (glm::vec3(x + 1, y + 1, z + 1));
                artf->animation_transform.rotation_center =
                        artf->world_transform.matrix() * glm::vec4(0,3,0,1);
                artf->rotation_rate = ((x + y + z) % 12 * M_PI / 24);
                double n1 = number - 1;
                artf->surface_material.ambient_color = cs4722::color(x / n1, y / n1,z / n1, 1.0);
				artifact_list.push_back(artf);
			}
		}
	}
    vao = cs4722::init_buffers(shader->ID, artifact_list, "b_position");
}



void render()
{
    static auto last_time = 0.0;
    auto time = glfwGetTime();
    auto delta_time = time - last_time;
    last_time = time;

    auto view_transform = glm::lookAt(the_view->camera_position,
                                      the_view->camera_position + the_view->camera_forward,
                                      the_view->camera_up);
    auto projection_transform = glm::infinitePerspective(the_view->perspective_fovy,
                                                         the_view->perspective_aspect, the_view->perspective_near);
    auto vp_transform = projection_transform * view_transform;

    /*
     * The light is uniform for the whole drawing operation.
     * The light belongs to the scene not to any particular artifact.
     * So, the ambient light value is sent to the fragment shader outside of the artifact loop.
     */
    shader->setVec4("u_ambient_light", a_light.ambient_light.as_float_array());

	for (auto artf: artifact_list) {
		artf->animate(time, delta_time);
        auto model_transform = artf->animation_transform.matrix() * artf->world_transform.matrix();
        auto transform = vp_transform * model_transform;
        shader->setMat4("u_transform", transform);
        shader->setVec4("u_ambient_color", artf->surface_material.ambient_color.as_float_array());
		glDrawArrays(GL_TRIANGLES, artf->the_shape->buffer_start,
			artf->the_shape->buffer_size);
	}
}




int
main(int argc, char** argv)
{
	glfwInit();
    cs4722::set_opengl_43();
    GLFWwindow *window = cs4722::setup_window_9_16_9("Ambient Light");
    gladLoadGL(glfwGetProcAddress);
	init();
    the_view->perspective_aspect = cs4722::get_aspect_ratio(window);

	glfwSetWindowUserPointer(window, the_view);
    glfwSetKeyCallback(window, general_key_callback);
    glfwSetCursorPosCallback(window, move_callback);
    glfwSetWindowSizeCallback(window, window_size_callback);

	while (!glfwWindowShouldClose(window))
	{
        glClearBufferfv(GL_COLOR, 0, cs4722::x11::gray25.as_float_array());
        glClear(GL_DEPTH_BUFFER_BIT);

        render();
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwDestroyWindow(window);

	glfwTerminate();
}
