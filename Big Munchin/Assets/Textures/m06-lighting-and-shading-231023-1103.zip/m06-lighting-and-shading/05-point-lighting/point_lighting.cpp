
/**
 * Starting with the no-lighting project, there are numerous changes needed to support shading.
 *      * A light object is defined
 *      * The light's ambient, diffuse, and specular components must be sent to the fragment shader
 *      * The specular, ambient, and diffuse colors of the surface material of each part must be
 *          sent to the fragment shader
 *      * The surface's shininess and specular strength must be sent to the fragment shader
 *      * Because shading is computed in the view frame (in this implementation)  the model-view
 *          transform must be sent to the vertex shader
 *
 *   Changes are needed in the shaders.  See those for comments
 */


#include <GLM/gtc/type_ptr.hpp>
#include <GLM/gtc/matrix_inverse.hpp>

#include <iostream>


#include <glad/gl.h>
#include <GLFW/glfw3.h>

#include "learnopengl/shader_4722.h"

#include "cs4722/artifact.h"
#include "cs4722/view.h"
#include "cs4722/light.h"
#include "cs4722/window.h"
#include "cs4722/buffer_utilities.h"
#include "../callbacks.h"

static cs4722::view *the_view;
static Shader *shader;

static std::vector<cs4722::artifact*> artifact_list;

static cs4722::light a_light;

void init()
{
    the_view = new cs4722::view();
    the_view->enable_logging = false;
    a_light.ambient_light = cs4722::x11::gray25;
//    a_light.is_directional = false;
    a_light.light_direction_position = glm::vec4(0,0,0,1);

    shader = new Shader("vertex_shader05.glsl",
                  "fragment_shader05.glsl");
	shader->use();

    glEnable(GL_DEPTH_TEST);


	// create a list of shapes that will be shared by the artifacts we have

	const auto color_set = std::vector <cs4722::color>({
			cs4722::x11::white, cs4722::x11::grey50, cs4722::x11::grey75,
		});
	
	auto* shape_list = new std::vector<cs4722::shape*>();
	shape_list->push_back(new cs4722::sphere());
	shape_list->push_back(new cs4722::block());
	shape_list->push_back(new cs4722::torus());
	shape_list->push_back(new cs4722::cylinder());
	auto numshp = shape_list->size();



	auto number = 4;
	auto d = 20.0f / (2 * number + 1);
	auto radius = d / 4;
	auto base = -number * d / 2 + radius;

	for (auto x = 0; x < number; ++x)
	{
		for (auto y = 0; y < number; ++y)
		{
			for (auto z = 0; z < number; ++z)
			{
				auto* artf = new cs4722::artifact_rotating();
				artf->the_shape = (shape_list->at((x + y + z) % numshp));
				artf->world_transform.translate = (glm::vec3(base + x * d, base + y * d, base + z * d));
				artf->world_transform.scale = (glm::vec3(radius, radius, radius));
                artf->animation_transform.rotation_axis = (glm::vec3(x + 1, y + 1, z + 1));
                artf->animation_transform.rotation_center =
                        artf->world_transform.matrix() * glm::vec4(0,3,0,1);
                artf->rotation_rate = ((x + y + z) % 12 * M_PI / 24);
                /**
                 * The surface material is set up.
                 * The same color is used for the ambient color and the diffuse color.
                 * The specular color is set to white
                 */
                double n1 = number - 1;
                artf->surface_material.ambient_color = cs4722::color(x / n1, y / n1,z / n1, 1.0);
                artf->surface_material.specular_color = cs4722::x11::white;
				artf->surface_material.diffuse_color = artf->surface_material.ambient_color;
				artf->surface_material.specular_strength = .75;
				artf->surface_material.shininess = 30.0;
				artifact_list.push_back(artf);
			}
		}
	}

    cs4722::init_buffers(shader->ID, artifact_list, "b_position","",
                         "", "b_normal");

}



void display()
{

    static auto last_time = 0.0;
    auto time = glfwGetTime();
    auto delta_time = time - last_time;
    last_time = time;

    auto view_transform = glm::lookAt(the_view->camera_position,
                                      the_view->camera_position + the_view->camera_forward,
                                      the_view->camera_up);
    auto projection_transform = glm::infinitePerspective(the_view->perspective_fovy,
                                                         the_view->perspective_aspect,
                                                         the_view->perspective_near);
    auto vp_transform = projection_transform * view_transform;

    shader->setVec4("u_light_position", a_light.light_direction_position);
    shader->setVec3("u_camera_position", the_view->camera_position);



	for (auto artf: artifact_list) {

		artf->animate(time, delta_time);
        auto model_transform = artf->animation_transform.matrix() * artf->world_transform.matrix();

        //
        /**
         *      The model-view-projection transform we have been sending to the vertex shader
         *          is here replaced by two separate parts: the model transform and
         *          the view-projection.
         *          These will be combined in the vertex shader.
         *          But, the model transform is needed there to convert to world coordinates
         *          so it's easier to set the transforms up this way
         */
        shader->setMat4("u_m_transform", model_transform);
        shader->setMat4("u_vp_transform", vp_transform);
        shader->setMat4("u_normal_transform", glm::inverseTranspose(model_transform));


        shader->setVec4("u_ambient_light", a_light.ambient_light.as_float_array());
        shader->setVec4("u_diffuse_light", a_light.diffuse_light.as_float_array());
        shader->setVec4("u_specular_light", a_light.specular_light.as_float_array());
        shader->setVec4("u_ambient_color", artf->surface_material.ambient_color.as_float_array());
        shader->setVec4("u_diffuse_color", artf->surface_material.diffuse_color.as_float_array());
        shader->setVec4("u_specular_color", artf->surface_material.specular_color.as_float_array());
        shader->setFloat("u_specular_shininess", artf->surface_material.shininess);
        shader->setFloat("u_specular_strength", artf->surface_material.specular_strength);


        glDrawArrays(GL_TRIANGLES, artf->the_shape->buffer_start,
			artf->the_shape->buffer_size);
		
	}
}




int
main(int argc, char** argv)
{
	glfwInit();
    cs4722::set_opengl_43();
    GLFWwindow *window = cs4722::setup_window_9_16_9("Visualize Normals");

    gladLoadGL(glfwGetProcAddress);
//	cs4722::setup_debug_callbacks();

	init();
    the_view->perspective_aspect = cs4722::get_aspect_ratio(window);

	glfwSetWindowUserPointer(window, the_view);
    glfwSetKeyCallback(window, general_key_callback);
    glfwSetCursorPosCallback(window, move_callback);
    glfwSetWindowSizeCallback(window, window_size_callback);

	while (!glfwWindowShouldClose(window))
	{
        glClearBufferfv(GL_COLOR, 0, cs4722::x11::gray25.as_float_array());
        glClear(GL_DEPTH_BUFFER_BIT);

        display();
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwDestroyWindow(window);

	glfwTerminate();
}
